// content.js

// Function to replace Robux spans, counters, and text with Tix
function replaceRobuxElements() {
    console.log('Running replaceRobuxElements function...');
    
    // Replace Robux icons
    const iconSpans = document.querySelectorAll('span.icon-robux-28x28');
    const counters = document.querySelectorAll('.robux-counter'); // Adjust selector if needed

    console.log('Found Robux icon spans:', iconSpans.length);
    console.log('Found Robux counters:', counters.length);

    // Replace Robux icons
    iconSpans.forEach(span => {
        console.log('Replacing Robux icon span:', span);

        // Create a new anchor element
        const anchor = document.createElement('a');
        anchor.href = 'https://www.roblox.com/upgrades/robux?ctx=navpopover'; // Link to Buy Robux page
        anchor.target = '_blank'; // Open in a new tab

        // Create a new img element for Tix
        const tixImg = document.createElement('img');
        tixImg.src = 'https://i.postimg.cc/2jLnWDr3/tix.webp'; // Remote URL for Tix icon
        tixImg.style.width = '28px'; // Match the size of the original icon
        tixImg.style.height = '28px'; // Match the size of the original icon
        tixImg.style.display = 'inline-block'; // Ensure proper display
        tixImg.style.position = 'relative'; // Ensure correct positioning

        // Replace existing Robux span with new Tix image
        anchor.appendChild(tixImg);
        span.parentNode.replaceChild(anchor, span);

        // Debugging information
        console.log('Tix image added to the DOM.');
    });

    // Replace or hide Robux counters
    counters.forEach(counter => {
        console.log('Handling Robux counter:', counter);
        // Option 1: Replace counter with something else (e.g., Tix counter or text)
        // Option 2: Hide the counter
        counter.style.display = 'none'; // Hide the counter
    });

    // Replace text "Robux", "Bobux", "Robox" with "Tix" (case-insensitive)
    replaceTextInDocument(document.body);
}

// Function to replace text content in the document
function replaceTextInDocument(element) {
    const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT, null, false);
    let node;

    while (node = walker.nextNode()) {
        const originalText = node.nodeValue;
        const newText = originalText
            .replace(/(Robux|Bobux|Robox)/gi, 'Tix'); // Case-insensitive replacement for all target words
        if (originalText !== newText) {
            node.nodeValue = newText;
            console.log('Replaced text:', originalText, 'with:', newText);
        }
    }
}

// Function to handle replacement on specific URLs
function handlePageChanges() {
    console.log('Handling page changes...');
    
    if (window.location.href.includes('roblox.com/upgrades/robux')) {
        // Replace Robux icons and text on the Buy Robux page
        replaceRobuxElements();
    }
}

// Run on initial load
window.addEventListener('load', () => {
    replaceRobuxElements();
    handlePageChanges();
});

// Observe DOM changes to replace dynamic elements
const observer = new MutationObserver(() => {
    replaceRobuxElements();
    handlePageChanges();
});

observer.observe(document.body, {
    childList: true,
    subtree: true
});
